from django import forms
from .models import Post, Comment, Candidato, Voto
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

# Formulario para publicaciones
class PostForm(forms.ModelForm):
    class Meta:
        model = Post  
        fields = ['title', 'content', 'category', 'candidato', 'published']
        labels = {
            'title': 'Título',
            'content': 'Contenido',
            'category': 'Categoría',
            'candidato': 'Candidato',
            'published': '¿Publicar ahora?',
        }
        widgets = {
            'title': forms.TextInput(attrs={'id': 'title'}),
            'content': forms.Textarea(attrs={'id': 'content', 'rows': 5}),
            'category': forms.Select(attrs={'id': 'category'}),
            'candidato': forms.Select(attrs={'id': 'candidato'}),
            'published': forms.CheckboxInput(attrs={'id': 'published'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['candidato'].queryset = Candidato.objects.all()
        self.fields['candidato'].label_from_instance = lambda obj: obj.nombre_completo


# Formulario para comentarios
class CommentForm(forms.ModelForm):
    class Meta:
        model = Comment
        fields = ['content']
        widgets = {
            'content': forms.Textarea(attrs={'rows': 3, 'placeholder': 'Escribe un comentario...'})
        }

# Formulario para candidaturas

class CandidatoForm(forms.ModelForm):
    class Meta:
        model = Candidato
        fields = ['nombre_completo','partido_politico', 'edad', 'imagen']


# Formulario para votos
class VotoForm(forms.ModelForm):
    class Meta:
        model = Voto
        fields = ['candidato']

# forms.py

class RegistroUsuarioForm(UserCreationForm):
    email = forms.EmailField(required=True)

    class Meta:
        model = User
        fields = ['first_name', 'last_name', 'username', 'email', 'password1', 'password2']

class PublicacionForm(forms.ModelForm):
    class Meta:
        model = Post
        fields = ['title', 'content', 'category', 'candidato', 'published']

class EditarCandidatoForm(forms.ModelForm):
    class Meta:
        model = Candidato
        exclude = ['usuario', 'nombre_completo']        