from django.shortcuts import render, redirect, get_object_or_404
from .forms import PostForm, CommentForm, CandidatoForm, RegistroUsuarioForm, PublicacionForm, EditarCandidatoForm
from django.contrib.auth.models import User
from .models import Post, Category, Candidato, Voto, Comment
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Count
from django.http import HttpResponseForbidden
import matplotlib
from django.core.files.uploadedfile import InMemoryUploadedFile
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from io import BytesIO
import base64

# Página principal
def index(request):
    publicaciones_recientes = Post.objects.all().order_by('-created_at')[:6]
    return render(request, 'post/index.html', {'publicaciones_recientes': publicaciones_recientes})

# Registro de usuario
# views.py
# post/views.py

def registrarse(request):
    if request.method == 'POST':
        form = RegistroUsuarioForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, '¡Registro exitoso! Ahora puedes iniciar sesión.')
            return redirect('login')
    else:
        form = RegistroUsuarioForm()

    return render(request, 'post/registro.html', {'form': form})

# Vista de categorías y filtrado
@login_required
def categorias(request):
    categorias = Category.objects.all()
    publicaciones = Post.objects.all().order_by('-created_at')
    
    categoria_id = request.GET.get('categoria')
    candidato_id = request.GET.get('candidato')
    
    candidatos = Candidato.objects.all()
    candidato_seleccionado = None

    if categoria_id:
        categoria = get_object_or_404(Category, id=categoria_id)
        publicaciones = publicaciones.filter(category=categoria)

    if candidato_id:
        try:
            candidato_seleccionado = Candidato.objects.get(id=candidato_id)
            publicaciones = publicaciones.filter(candidato=candidato_seleccionado)
        except Candidato.DoesNotExist:
            messages.error(request, 'El candidato seleccionado no existe.')

    return render(request, 'post/categorias.html', {
        'categorias': categorias,
        'publicaciones': publicaciones,
        'categoria_seleccionada': categoria_id,
        'candidatos': candidatos,
        'candidato_seleccionado': int(candidato_id) if candidato_id else None,
    })


# Vista de publicaciones según usuario
@login_required
def publicaciones(request):
    
    if request.user.is_superuser or request.user.is_staff:
        posts = Post.objects.all().order_by('-created_at')
    else:
        posts = Post.objects.filter(author=request.user).order_by('-created_at')
    return render(request, 'post/publicaciones.html', {'posts': posts})

# Vista de perfil del usuario
@login_required
def perfil(request):
    return render(request, 'post/perfil_usuario.html', {'usuario': request.user})

# Crear nueva publicación
@login_required
def nueva_publicacion(request):
    if request.method == 'POST':
        form = PostForm(request.POST)
        if form.is_valid():
            post = form.save(commit=False)
            post.author = request.user
            # Asignamos candidato desde request.POST
            candidato_id = request.POST.get('candidato')
            if candidato_id:
                post.candidato_id = candidato_id
            post.save()
            return redirect('publicaciones')
    else:
        form = PostForm()

    candidatos = Candidato.objects.all()
    return render(request, 'post/nueva_publicacion.html', {
        'form': form,
        'candidatos': candidatos,
        'candidato_seleccionado': request.POST.get('candidato', '')
    })


# Editar publicación existente
@login_required
def editar_publicacion(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    if request.method == 'POST':
        form = PostForm(request.POST, instance=post)
        if form.is_valid():
            form.save()
            return redirect('publicaciones')
    else:
        form = PostForm(instance=post)
    return render(request, 'post/editar_publicacion.html', {'form': form})

# Eliminar publicación
@login_required
def eliminar_publicacion(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    if request.method == 'POST':
        post.delete()
        return redirect('publicaciones')
    return render(request, 'post/borrar_publicacion.html', {'post': post})

# Detalle de una publicación
def detalle_publicacion(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    comentarios = post.comments.all().order_by('-created_at')
    form = CommentForm()

    if request.method == 'POST' and request.user.is_authenticated:
        form = CommentForm(request.POST)
        if form.is_valid():
            comentario = form.save(commit=False)
            comentario.post = post
            comentario.author = request.user
            comentario.save()
            return redirect('detalle_publicacion', post_id=post.id)

    return render(request, 'post/detalle_publicacion.html', {
        'post': post,
        'comentarios': comentarios,
        'form': form
    })

# Registrar candidatura
@login_required
def registrar_candidato(request):
    # Verifica si el usuario ya tiene un candidato
    if Candidato.objects.filter(usuario=request.user).exists():
        messages.info(request, 'Ya has sido registrado como candidato.')
        return redirect('datos_candidato')  # Redirige a la vista para ver sus datos

    if request.method == 'POST':
        form = CandidatoForm(request.POST, request.FILES)
        if form.is_valid():
            candidato = form.save(commit=False)
            candidato.usuario = request.user
            candidato.save()
            messages.success(request, '¡Candidatura registrada exitosamente!')
            return redirect('datos_candidato')  # Redirige después del registro
    else:
        form = CandidatoForm()

    return render(request, 'post/registrar_candidato.html', {'form': form})

# Registrar voto o modificarlo
@login_required
def registrar_voto(request):
    candidatos = Candidato.objects.all()
    voto_existente = Voto.objects.filter(usuario=request.user).first()

    if request.method == 'POST':
        candidato_id = request.POST.get('candidato')
        candidato = get_object_or_404(Candidato, id=candidato_id)

        if voto_existente:
            voto_existente.candidato = candidato
            voto_existente.save()
            messages.success(request, '¡Tu voto ha sido actualizado!')
        else:
            Voto.objects.create(usuario=request.user, candidato=candidato)
            messages.success(request, '¡Voto registrado exitosamente!')

        return redirect('registrar_voto')

    return render(request, 'post/registrar_voto.html', {
        'candidatos': candidatos,
        'voto_existente': voto_existente
    })

# Resultados de votaciones con gráfico

def resultados_votaciones(request):
    votos = Voto.objects.select_related('candidato').all()

    conteo = {}
    total_votos = votos.count()
    for voto in votos:
        candidato = voto.candidato
        if candidato.id not in conteo:
            conteo[candidato.id] = {
                'candidato': candidato,
                'total': 0
            }
        conteo[candidato.id]['total'] += 1

    resultados = sorted(conteo.values(), key=lambda x: x['total'], reverse=True)

    # Datos para el gráfico
    nombres = [r['candidato'].nombre_completo for r in resultados]
    totales = [r['total'] for r in resultados]

    for resultado in resultados:
        resultado['porcentaje'] = (resultado['total'] / total_votos) * 100 if total_votos > 0 else 0

    # Gráfico de barras
    plt.figure(figsize=(10, 5))
    plt.bar(nombres, totales, color='skyblue')
    plt.title('Resultados de la votación - Barras')
    plt.xlabel('Candidato')
    plt.ylabel('Cantidad de votos')
    plt.xticks(rotation=45)
    buffer_barras = BytesIO()
    plt.tight_layout()
    plt.savefig(buffer_barras, format='png')
    buffer_barras.seek(0)
    grafico_barras = base64.b64encode(buffer_barras.read()).decode('utf-8')
    buffer_barras.close()
    plt.close()

    # Gráfico de línea
    plt.figure(figsize=(10, 5))
    plt.plot(nombres, totales, marker='o', linestyle='-', color='green')
    plt.title('Resultados de la votación - Línea')
    plt.xlabel('Candidato')
    plt.ylabel('Cantidad de votos')
    plt.xticks(rotation=45)
    buffer_linea = BytesIO()
    plt.tight_layout()
    plt.savefig(buffer_linea, format='png')
    buffer_linea.seek(0)
    grafico_linea = base64.b64encode(buffer_linea.read()).decode('utf-8')
    buffer_linea.close()
    plt.close()

    # Gráfico circular
    plt.figure(figsize=(6, 6))
    plt.pie(totales, labels=nombres, autopct='%1.1f%%', startangle=90)
    plt.title('Distribución de votos - Circular')
    plt.axis('equal')
    buffer_circular = BytesIO()
    plt.tight_layout()
    plt.savefig(buffer_circular, format='png')
    buffer_circular.seek(0)
    grafico_circular = base64.b64encode(buffer_circular.read()).decode('utf-8')
    buffer_circular.close()
    plt.close()

    return render(request, 'post/resultados_votaciones.html', {
        'resultados': resultados,
        'imagen_barras': grafico_barras,
        'imagen_lineal': grafico_linea,
        'imagen_circular': grafico_circular,
    })


@login_required
def datos_candidato(request):
    try:
        candidato = request.user.candidato
    except Candidato.DoesNotExist:
        return redirect('registrar_candidato')

    if request.method == 'POST':
        form = EditarCandidatoForm(request.POST, request.FILES, instance=candidato)
        if form.is_valid():
            form.save()
            messages.success(request, 'Datos actualizados correctamente.')
            return redirect('datos_candidato')
    else:
        form = EditarCandidatoForm(instance=candidato)

    return render(request, 'post/editar_datos_candidato.html', {
        'form': form,
        'candidato': candidato
        })


@login_required
def eliminar_candidatura(request):
    candidato = get_object_or_404(Candidato, usuario=request.user)
    candidato.delete()
    return redirect('registrar_candidato')  # o a la vista que desees mostrar luego



@login_required
def editar_comentario(request, comentario_id):
    comentario = get_object_or_404(Comment, id=comentario_id)

    if request.user != comentario.author:
        return HttpResponseForbidden("No tienes permiso para editar este comentario.")

    if request.method == 'POST':
        form = CommentForm(request.POST, instance=comentario)
        if form.is_valid():
            form.save()
            messages.success(request, "Comentario actualizado correctamente.")
            return redirect('detalle_publicacion', post_id=comentario.post.id)
    else:
        form = CommentForm(instance=comentario)

    return render(request, 'post/editar_comentario.html', {
        'form': form,
        'comentario': comentario
    })


@login_required
def eliminar_comentario(request, comentario_id):
    comentario = get_object_or_404(Comment, id=comentario_id)

    if request.user != comentario.author:
        return HttpResponseForbidden("No tienes permiso para eliminar este comentario.")

    if request.method == 'POST':
        comentario.delete()
        messages.success(request, "Comentario eliminado correctamente.")
        return redirect('detalle_publicacion', post_id=comentario.post.id)

    return render(request, 'post/confirmar_eliminar_comentario.html', {
        'comentario': comentario
    })

@login_required
def subir_foto_perfil(request):
    if request.method == 'POST':
        profile = request.user.profile
        foto = request.FILES.get('foto')
        if foto:
            profile.foto = foto
            profile.save()
            messages.success(request, 'Foto de perfil actualizada.')
        return redirect('perfil')
    return redirect('perfil')

@login_required
def eliminar_foto_perfil(request):
    perfil = request.user.profile
    if perfil.foto:
        perfil.foto.delete()
        perfil.foto = None
        perfil.save()
    return redirect('perfil')

def publicaciones_por_categoria(request, categoria_id):
    categoria = get_object_or_404(Category, id=categoria_id)
    publicaciones = Post.objects.filter(categoria=categoria)
    return render(request, 'post/publicaciones_por_categoria.html', {
        'categoria': categoria,
        'publicaciones': publicaciones
    })


def publicaciones_por_candidato(request, candidato_id):
    candidato = get_object_or_404(Candidato, id=candidato_id)
    publicaciones = Post.objects.filter(autor=candidato.user).order_by('-fecha_creacion')
    return render(request, 'post/publicaciones_por_candidato.html', {
        'candidato': candidato,
        'publicaciones': publicaciones
    })

def lista_publicaciones(request):
    publicaciones = Post.objects.filter(publicar=True).order_by('-fecha_creacion')
    return render(request, 'post/lista_publicaciones.html', {'publicaciones': publicaciones})

@login_required
def nueva_publicacion(request):
    if request.method == 'POST':
        form = PostForm(request.POST, request.FILES)
        if form.is_valid():#manejo de peticiones del formulario
            post = form.save(commit=False)
            post.author = request.user
            post.save()
            messages.success(request, 'Publicación creada con éxito.')
            return redirect('detalle_publicacion', post_id=post.id)
        else:
            messages.error(request, 'Por favor corrige los errores en el formulario.')
    else:
        form = PostForm()

    candidatos = Candidato.objects.all()
    candidato_seleccionado = request.POST.get('candidato', '') if request.method == 'POST' else ''

    return render(request, 'post/nueva_publicacion.html', {
        'form': form,
        'candidatos': candidatos,
        'candidato_seleccionado': candidato_seleccionado
    })



def crear_publicacion(request):
    if request.method == 'POST':
        form = PublicacionForm(request.POST)
        candidato_id = request.POST.get('candidato')
        if form.is_valid():
            publicacion = form.save(commit=False)
            if candidato_id:
                publicacion.candidato = Candidato.objects.get(id=candidato_id)
            publicacion.author = request.user
            publicacion.save()
            return redirect('post:detalle_publicacion', post_id=publicacion.id)
    else:
        form = PublicacionForm()

    candidatos = Candidato.objects.all()  # ← esto es lo que llena el select
    return render(request, 'post/crear_publicacion.html', {
        'form': form,
        'candidatos': candidatos,
        'candidato_seleccionado': None,
    })

@login_required
def nueva_publicacion(request):
    if request.method == 'POST':
        form = PostForm(request.POST)
        if form.is_valid():
            post = form.save(commit=False)
            post.author = request.user  # 👈🏽 ¡Esto es lo que faltaba!
            post.save()
            return redirect('post:lista_publicaciones')
    else:
        form = PostForm()
    return render(request, 'post/nueva_publicacion.html', {'form': form})


def editar_publicacion(request, post_id):
    post = get_object_or_404(Post, id=post_id)

    if request.method == 'POST':
        form = PublicacionForm(request.POST, instance=post)
        candidato_id = request.POST.get('candidato')
        if form.is_valid():
            publicacion = form.save(commit=False)
            
            # Asocia el candidato si se seleccionó uno
            if candidato_id:
                publicacion.candidato = Candidato.objects.get(id=candidato_id)
            else:
                publicacion.candidato = None

            publicacion.save()
            return redirect('post:detalle_publicacion', post_id=publicacion.id)
    else:
        form = PublicacionForm(instance=post)
        candidato_seleccionado = post.candidato.id if post.candidato else None

    candidatos = Candidato.objects.all()
    return render(request, 'post/editar_publicacion.html', {
        'form': form,
        'post': post,
        'candidatos': candidatos,
        'candidato_seleccionado': candidato_seleccionado,
    })
