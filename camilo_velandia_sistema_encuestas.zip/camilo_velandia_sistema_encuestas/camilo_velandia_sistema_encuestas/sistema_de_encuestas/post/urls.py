from django.urls import path
from . import views
from django.contrib.auth import views as auth_views  # Para login/logout

urlpatterns = [
    path('', views.index, name='index'),
    path('categorias/', views.categorias, name='categorias'),
    path('publicaciones/', views.publicaciones, name='publicaciones'),
    path('perfil/', views.perfil, name='perfil'),
    path('publicaciones/nueva/', views.nueva_publicacion, name='nueva_publicacion'),
    path('publicaciones/editar/<int:post_id>/', views.editar_publicacion, name='editar_publicacion'),
    path('publicaciones/eliminar/<int:post_id>/', views.eliminar_publicacion, name='eliminar_publicacion'),
    path('post/<int:post_id>/', views.detalle_publicacion, name='detalle_publicacion'),
    # Registro y autenticación
    path('registro/', views.registrarse, name='registro'),
    path('login/', auth_views.LoginView.as_view(template_name='post/login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(next_page='login'), name='logout'),

    # Votaciones
    path('registrar-candidato/', views.registrar_candidato, name='registrar_candidato'),
    path('registrar-voto/', views.registrar_voto, name='registrar_voto'),
    path('resultados/', views.resultados_votaciones, name='resultados_votaciones'),
    path('datos-candidato/', views.datos_candidato, name='datos_candidato'),
    path('eliminar_candidatura/', views.eliminar_candidatura, name='eliminar_candidatura'),
    path('comentario/eliminar/<int:comentario_id>/', views.eliminar_comentario, name='eliminar_comentario'),
    path('comentario/editar/<int:comentario_id>/', views.editar_comentario, name='editar_comentario'),
    path('comentario/<int:comentario_id>/editar/', views.editar_comentario, name='editar_comentario'),
    path('comentario/<int:comentario_id>/eliminar/', views.eliminar_comentario, name='eliminar_comentario'),

    path('subir-foto/', views.subir_foto_perfil, name='subir_foto_perfil'),
    path('eliminar-foto-perfil/', views.eliminar_foto_perfil, name='eliminar_foto_perfil'),
    path('', views.lista_publicaciones, name='lista_publicaciones'),
    path('publicaciones/nueva/', views.nueva_publicacion, name='nueva_publicacion'),
    path('publicaciones/<int:post_id>/editar/', views.editar_publicacion, name='editar_publicacion'),

    # NUEVA RUTA: publicaciones filtradas por categoría
    path('categoria/<int:categoria_id>/', views.publicaciones_por_categoria, name='publicaciones_por_categoria'),
    path('candidato/<int:candidato_id>/', views.publicaciones_por_candidato, name='publicaciones_por_candidato'),
]
